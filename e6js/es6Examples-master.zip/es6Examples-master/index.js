for (let i = 1; i<4; i++) {
    console.log(i);
}
console.log(i);