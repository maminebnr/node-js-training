const nom = 'aymen';
function getAge() {
  return 38;
}
const monObjet = {
  [nom + getAge()]: "Computer Science",
};
console.log(monObjet);
